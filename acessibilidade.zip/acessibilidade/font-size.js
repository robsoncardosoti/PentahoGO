var fontSize = 1;
function increaseFont() {
	fontSize += 0.1;
	document.body.style.fontSize = fontSize + "em";
}
function decreaseFont() {
	fontSize -= 0.1;
	document.body.style.fontSize = fontSize + "em";
}
